

var another = new Object();


another.codeName = ("another")
another.title = ("Another")
another.categoria = ("Anime")
another.episodios = ("Episodios: " + 13);
another.episodio = 13;
another.sinopsis = ("Trata de un wey que se transfiere a una escuela con mas misterio que mi vida, donde alumnos mueren misteriosamente.")
another.rate = ("6/10")
another.genero = ["Misterio", " Horror", " Psicológico"]
another.img = ("img/another.jpg")
another.descarga=("https://ouo.io/OyjG73")

var bokuDake = new Object();


bokuDake.codeName = ("bokuDake")
bokuDake.title = ("Boku Dake ga inai Machi")
bokuDake.categoria = ("Anime")
bokuDake.episodios = "Episodios: " + 12;
bokuDake.episodio = 12;
bokuDake.sinopsis = ("Trata de un wey, que viaja al pasado, para resolver su pasado de pendejo.")
bokuDake.rate = ("7/10")
bokuDake.genero = ["Ciencia Ficción", " Aventura", " Psicológico"]
bokuDake.img = ("img/bokuDake.jpg")
bokuDake.descarga=("https://ouo.io/2kjNin")


var danshiKoukousei = new Object();



danshiKoukousei.codeName = ("danshiKoukousei")
danshiKoukousei.title = ("Danshi Koukousei no Nichijou")
danshiKoukousei.categoria = ("Anime")
danshiKoukousei.episodios = "Episodios: " + 12;
danshiKoukousei.episodio = 12;
danshiKoukousei.sinopsis = ("Trata de una escuela de weyes, otacos, que no tienen novia. El anime tiene muy buena comedia, anime muy recomendado y uno de los mejores en su género.")
danshiKoukousei.rate = ("7/10")
danshiKoukousei.genero = ["Comedia", " Escolar", " Cosas de la Vida"]
danshiKoukousei.img = ("img/danshiKoukousei.jpg")
danshiKoukousei.descarga=("https://ouo.io/vnazgq")




var deadmanW = new Object();



deadmanW.codeName = ("deadmanW")
deadmanW.title = ("Deadman WonderLand")
deadmanW.categoria = ("Anime")
deadmanW.episodios = "Episodios: " + 13;
deadmanW.episodio = 13;
deadmanW.sinopsis = ("Trata de una prision, en el que todos estan condenados a pena de muerte, nadie le importa si mueren, y en medio de todo esto colocamos a un personaje princeso, y booom!")
deadmanW.rate = ("6/10")
deadmanW.genero = ["Acción", " Horror", " Ciencia Ficción"]
deadmanW.img = ("img/deadmanWonderland.jpg")
deadmanW.descarga=("http://ouo.io/8bB9Sl")



var elfenLied = new Object();



elfenLied.codeName = ("elfenLied")
elfenLied.title = ("Elfen Lied")
elfenLied.categoria = ("Anime")
elfenLied.episodios = "Episodios: " + 13;
elfenLied.episodio = 13;
elfenLied.sinopsis = ("Trata de una wey sicopata con poderes mentales bien chungos, este anime es gore (a más no poder) y puede tener escenas de desnudos.")
elfenLied.rate = ("7/10")
elfenLied.genero = ["Ciencia Ficción", " Gore", " Drama"]
elfenLied.img = ("img/elfenLied.jpg")
elfenLied.descarga=("http://ouo.io/9YBHOfp")



var miraiNikki = new Object();



miraiNikki.codeName = ("miraiNikki")
miraiNikki.title = ("Mirai Nikki")
miraiNikki.categoria = ("Anime")
miraiNikki.episodios = "Episodios: " + 26;
miraiNikki.episodio = 26;
miraiNikki.sinopsis = ("Trata de 'diaros' que predicen el futuro, en el anime todos tendrán que luchar por sobrevivir y el protagonista es otro princeso.")
miraiNikki.rate = ("8/10")
miraiNikki.genero = ["Ciencia Ficción", " Aventura", " Psicológico"]
miraiNikki.img = ("img/miraiNikki.jpg")
miraiNikki.descarga=("#")




allAnimes = [another, bokuDake, danshiKoukousei, deadmanW, elfenLied, miraiNikki];





